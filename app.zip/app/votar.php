<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class votar extends Model
{
    //
}
