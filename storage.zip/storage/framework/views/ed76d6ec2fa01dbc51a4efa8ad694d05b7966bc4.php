<div id="page-content">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
          <div class="panel">
              <div class="panel-body np">
                  <div class="text-center">
                      <!-- panel body -->
                      <h4 class="text-lg text-overflow mar-top">Abdul Karim</h4>
                      <p class="text-sm">Phone: +88 01305634342</p>
                      <!--/ panel body -->

                  </div>
              </div>
          </div>
          <div class="panel">
              <div class="panel-heading">
                  <h3 class="panel-title"><i class="fa fa-user"> </i> Customer Information</h3>
              </div>
              <div class="panel-body">
                  <table class="table">
                      <tbody>
                          <tr>
                              <td><i class="fa fa-external-link ph-5"></i></td>
                              <td> Book Date: </td>
                              <td> 31/10/2019</td>
                          </tr>
                          <tr>
                              <td><i class="fa fa-edit ph-5"></i></td>
                              <td> Package Id: </td>
                              <td>#T846584</td>
                          </tr>
                          <tr>
                              <td><i class="fa fa-phone ph-5"></i></td>
                              <td> Phone : </td>
                              <td> +88 01305634342</td>
                          </tr>
                          <tr>
                              <td><i class="fa fa-envelope-o ph-5"></i></td>
                              <td> Email:  </td>
                              <td> karim@gmail.com</td>
                          </tr>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
        <div class="col-lg-8 col-md-8">
            <div class="panel">
                <div class="panel-body np"> <img src="<?php echo e(asset('asset/img/photos/hajj.jpg')); ?>" alt="Cover" class="img-responsive">
                    <div class="text-center">
                        <!-- panel body -->
                        <h4 class="text-lg text-overflow mar-top">Packages Title Here Packages Title Here</h4>
                        <p class="text-sm">Packages Id: #T846584</p>
                    </div>
                </div>
            </div>
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-user"> </i> Package Information</h3>
                </div>
                <div class="panel-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <td> Category : </td>
                                <td> Umrah Hajj</td>
                            </tr>
                            <tr>
                                <td> Location :</td>
                                <td>Mokkah </td>
                            </tr>
                            <tr>
                                <td> Duration :</td>
                                <td> 15 Nights/ 16 Days </td>
                            </tr>
                            <tr>
                                <td> Amount :</td>
                                <td> $5000 </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-4"></div>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
            <div class="panel">
                <div class="panel-body pad-no">

                  <!--Default Tabs (Left Aligned)-->
                  <!--===================================================-->
                  <div class="tab-base">
                    <div class="tab-content">
                      <div id="demo-lft-tab-1" class="tab-pane fade active in">

                        <!-- Timeline -->
                        <!--===================================================-->
                        <div class="timeline">

                          <!-- Timeline header -->
                          <div class="timeline-header">
                            <div class="timeline-header-title bg-info">Packages Description</div>
                          </div>
                          <div class="timeline-entry">
                            <div class="timeline-stat">
                              <div class="timeline-icon bg-purple"><i class="fa fa-check fa-lg"></i> </div>
                            </div>
                            <div class="timeline-label">
                              <div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat...</p>
                              </div>
                            </div>
                          </div>
                          <div class="timeline-entry">
                            <div class="timeline-stat">
                              <div class="timeline-icon bg-primary"><i class="fa fa-image fa-lg"></i> </div>
                            </div>
                            <div class="timeline-label">
                              <h4>Packages Related Photos</h4>
                              <div> <img src="img/photos/profile-pic-1.png" class="profile-img" alt=""></div>
                            </div>
                          </div>
                        </div>
                        <!--===================================================-->
                        <!-- End Timeline -->
                      </div>
                      <div id="demo-lft-tab-2" class="tab-pane fade">
                       <!--Hover Rows-->
                       <!--===================================================-->
                         <table class="table table-hover table-vcenter">
                           <thead>
                             <tr>
                                <th>Invoice</th>
                                <th>Name</th>
                                <th class="text-center">Value</th>
                                <th>Delivery date</th>
                                <th>Status</th>
                             </tr>
                           </thead>
                           <tbody>
                             <tr>
                                <td>Order #53451</td>
                                <td>
                                    <span class="text-semibold">Desktop</span>
                                    <br>
                                    <small class="text-muted">Last 7 days : 4,234k</small>
                                </td>
                                <td class="text-center">$250</td>
                                <td>2012/04/25</td>
                                <td><div class="label label-table label-info">On Process</div></td>
                             </tr>
                             <tr>
                                <td>Order #53451</td>
                                <td>
                                    <span class="text-semibold">Laptop</span>
                                    <br>
                                    <small class="text-muted">Last 7 days : 3,876k</small>
                                </td>
                                <td class="text-center">$350</td>
                                <td>2012/04/25</td>
                                <td><div class="label label-table label-danger">Cancelled</div></td>
                             </tr>
                             <tr>
                                <td>Order #53451</td>
                                <td>
                                    <span class="text-semibold">Tablet</span>
                                    <br>
                                    <small class="text-muted">Last 7 days : 45,678k</small>
                                </td>
                                <td class="text-center">$325</td>
                                <td>2012/04/25</td>
                                <td><div class="label label-table label-success">Shipped</div></td>
                             </tr>
                             <tr>
                                <td>Order #53451</td>
                                <td>
                                    <span class="text-semibold">Smartphone</span>
                                    <br>
                                    <small class="text-muted">Last 7 days : 34,553k</small>
                                </td>
                                <td class="text-center">$250</td>
                                <td>2012/04/25</td>
                                <td><div class="label label-table label-warning">Pending</div></td>
                             </tr>
                           </tbody>
                         </table>
                       <!--===================================================-->
                       <!--End Hover Rows-->

                      </div>
                    </div>
                  </div>
                  <!--===================================================-->
                  <!--End Default Tabs (Left Aligned)-->
               </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\e-RUS\resources\views/admin/pages/body.blade.php ENDPATH**/ ?>