<nav id="mainnav-container">
    <div id="mainnav">
        <!--Menu-->
        <!--================================-->
        <div id="mainnav-menu-wrap">
            <div class="nano">
                <div class="nano-content">
                    <ul id="mainnav-menu" class="list-group">
                        <!--Category name-->
                        <li class="list-header">Navigation</li>
                        <!--Menu list item-->
                        <li>
                            <a href="javascript:void(0)">
                            <i class="fa fa-home"></i>
                            <span class="menu-title">Dashboard</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="http://localhost:8000/dashboard"><i class="fa fa-caret-right"></i> Dashboard</a></li>
                            </ul>
                        </li>
                        <!--Menu list item-->
                        <li class="list-divider"></li>
                        <!--Category name-->
                        <li class="list-header">Components</li>
                        <!--Menu list item-->
                        <li>
                            <a href="#">
                            <i class="fa fa-th"></i>
                            <span class="menu-title">
                            <strong>Union Area</strong>
                            </span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="#"><i class="fa fa-caret-right"></i> Add Area Info </a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i> All Information </a></li>
                            </ul>
                        </li>
                        <!--Menu list item-->
                        <!--Menu list item-->
                        <li>
                            <a href="#">
                            <i class="fa fa-user"></i>
                            <span class="menu-title">census</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="#"><i class="fa fa-caret-right"></i> Add People Info </a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i> All People </a></li>
                            </ul>
                        </li>
                        <!--Menu list item-->

                        <li>
                            <a href="#">
                            <i class="fa fa-university"></i>
                            <span class="menu-title">Tax Management</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="add_education_packages.html"><i class="fa fa-caret-right"></i> Add Packages </a></li>
                                <li><a href="all_education_packages.html"><i class="fa fa-caret-right"></i> Packages List </a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                            <i class="fa fa-hospital-o"></i>
                            <span class="menu-title">Rason Management</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="add_medical_packages.html"><i class="fa fa-caret-right"></i> Add Packages </a></li>
                                <li><a href="all_medical_packages.html"><i class="fa fa-caret-right"></i> Packages List </a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                            <i class="glyphicon glyphicon-tags"></i>
                            <span class="menu-title">Booking Ticket</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="all_booking_list.html"><i class="fa fa-caret-right"></i> Booking List </a></li>
                                <li><a href="hajj_booking_list.html"><i class="fa fa-caret-right"></i> Hajj Booking </a></li>
                                <li><a href="work_booking_list.html"><i class="fa fa-caret-right"></i> Work Booking </a></li>
                                <li><a href="travel_booking_list.html"><i class="fa fa-caret-right"></i> Travel Booking </a></li>
                                <li><a href="education_booking_list.html"><i class="fa fa-caret-right"></i> Education Booking </a></li>
                                <li><a href="medical_booking_list.html"><i class="fa fa-caret-right"></i> Medical Booking </a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                            <i class="fa fa-book"></i>
                            <span class="menu-title">
                            Massages
                            </span>
                            </a>
                        </li>

                        <li class="list-divider"></li>
                        <!--Category name-->
                        <li class="list-header">Extra</li>
                        <li>
                            <a href="calendar.html">
                            <i class="glyphicon glyphicon-cog"></i>
                            <span class="menu-title">
                            Settings
                            </span>
                            </a>
                        </li>
                        <li>
                            <a href="calendar.html">
                            <i class="glyphicon glyphicon-off"></i>
                            <span class="menu-title">
                            Log Out
                            </span>
                            </a>
                        </li>
                        <!--Menu list item-->
                        <li>
                            <a href="ui-widgets.html">
                            <i class="glyphicon glyphicon-info-sign"></i>
                            <span class="menu-title">
                            <strong>About Us</strong>
                            </span>
                            </a>
                        </li>
                    </ul>
                    <!--Widget-->
                    <!--================================-->
                    <div class="mainnav-widget">
                        <!-- Show the button on collapsed navigation -->
                        <div class="show-small">
                            <a href="#" data-toggle="menu-widget" data-target="#demo-wg-server">
                            <i class="fa fa-desktop"></i>
                            </a>
                        </div>
                        <!-- Hide the content on collapsed navigation -->
                        <div id="demo-wg-server" class="hide-small mainnav-widget-content">
                            <ul class="list-group">
                                <li class="list-header pad-no pad-ver">Server Status</li>
                                <li class="mar-btm">
                                    <span class="label label-primary pull-right">15%</span>
                                    <p>CPU Usage</p>
                                    <div class="progress progress-sm">
                                        <div class="progress-bar progress-bar-primary" style="width: 15%;">
                                            <span class="sr-only">15%</span>
                                        </div>
                                    </div>
                                </li>
                                <li class="mar-btm">
                                    <span class="label label-purple pull-right">75%</span>
                                    <p>Bandwidth</p>
                                    <div class="progress progress-sm">
                                        <div class="progress-bar progress-bar-purple" style="width: 75%;">
                                            <span class="sr-only">75%</span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--================================-->
                    <!--End widget-->
                </div>
            </div>
        </div>
        <!--================================-->
        <!--End menu-->
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\e-RUS\resources\views/menu/nav.blade.php ENDPATH**/ ?>