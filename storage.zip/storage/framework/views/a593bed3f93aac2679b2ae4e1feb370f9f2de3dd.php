<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
	<meta content="Start your development with a Dashboard for Bootstrap 4." name="description">
	<meta content="Spruko" name="author">

	<!-- Title -->
	<title>Ansta - Responsive Multipurpose Admin Dashboard Template</title>

	<!-- Favicon -->
	<link href="assets/img/brand/favicon.png" rel="icon" type="image/png">

	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800" rel="stylesheet">

	<!-- Icons -->
	<link href="assets/css/icons.css" rel="stylesheet">

	<!--Bootstrap.min css-->
	<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">

	<!-- Ansta CSS -->
	<link href="assets/css/dashboard.css" rel="stylesheet" type="text/css">

	<!-- Tabs CSS -->
	<link href="assets/plugins/tabs/style.css" rel="stylesheet" type="text/css">

	<!-- jvectormap CSS -->
    <link href="assets/plugins/jvectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />

	<!-- Custom scroll bar css-->
	<link href="assets/plugins/customscroll/jquery.mCustomScrollbar.css" rel="stylesheet" />

	<!-- Sidemenu Css -->
	<link href="assets/plugins/toggle-sidebar/css/sidemenu.css" rel="stylesheet">

</head>
<body class="app sidebar-mini rtl" >
	<div id="global-loader" ></div>
	<div class="page">
		<div class="page-main">
			<!-- Sidebar menu-->
			<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
			<aside class="app-sidebar ">
				<div class="sidebar-img">
					<a class="navbar-brand" href="index.html"><img alt="..." class="navbar-brand-img main-logo" src="assets/img/brand/logo-dark.png"> <img alt="..." class="navbar-brand-img logo" src="assets/img/brand/logo.png"></a>
					<ul class="side-menu">
						<li class="slide">
							<a class="side-menu__item active" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-home"></i><span class="side-menu__label">Dashboard</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a class="slide-item" href="index.html">Retail Sales Dashboard</a>
								</li>
								<li>
									<a class="slide-item" href="dashboard-social.html">Social Dashboard</a>
								</li>
								<li>
									<a class="slide-item" href="dashboard-marketing.html">Marketing Dashboard</a>
								</li>
								<li>
									<a class="slide-item" href="dashboard-it.html">IT Dashboard</a>
								</li>
								<li>
									<a class="slide-item" href="dashboard-cryptocurrency.html">Cryptocurrency Dashboard</a>
								</li>

							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-grid"></i><span class="side-menu__label">Apps</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="cards.html" class="slide-item">Cards</a>
								</li>
								<li>
									<a href="dragable-cards.html" class="slide-item">Dragable Cards</a>
								</li>
								<li>
									<a href="widgets.html" class="slide-item">Widgets</a>
								</li>
								<li>
									<a href="full-calendar.html" class="slide-item">Full Calendar</a>
								</li>
								<li>
									<a href="range-slider.html" class="slide-item">Range Slider</a>
								</li>
								<li>
									<a href="scroll-bar.html" class="slide-item">Scroll Bar</a>
								</li>
								<li>
									<a href="sweet-alerts.html" class="slide-item">Sweet Alerts</a>
								</li>
								<li>
									<a href="timeline.html" class="slide-item">Timeline</a>
								</li>
								<li>
									<a href="users.html" class="slide-item">Users</a>
								</li>
							</ul>
						</li>

						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-edit"></i><span class="side-menu__label">Forms</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="forms.html" class="slide-item">Basic Forms</a>
								</li>
								<li>
									<a href="form-select2.html" class="slide-item">Forms Select2</a>
								</li>
								<li>
									<a href="file-uploads.html" class="slide-item">Forms Uploads</a>
								</li>
								<li>
									<a href="form-wizard.html" class="slide-item">Form wizard</a>
								</li>
								<li>
									<a href="datepicker.html" class="slide-item">Form Datepicker</a>
								</li>
								<li>
									<a href="form-switches.html" class="slide-item">Form switches</a>
								</li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-map"></i><span class="side-menu__label">Maps</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="maps.html" class="slide-item">Google Maps</a>
								</li>
								<li>
									<a href="vector-map.html" class="slide-item">Vector Map</a>
								</li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-file-text"></i><span class="side-menu__label">Tables</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="tables.html" class="slide-item">Tables</a>
								</li>
								<li>
									<a href="datatable.html" class="slide-item">Data Tables</a>
								</li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-bar-chart-2"></i><span class="side-menu__label">Chart Types</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="chart-flot.html" class="slide-item">Flot Charts</a>
								</li>
								<li>
									<a href="chart-high.html" class="slide-item">High Charts </a>
								</li>
								<li>
									<a href="charts-chartjs.html" class="slide-item">Chartjs Charts</a>
								</li>
								<li>
									<a href="charts-echarts.html" class="slide-item">Echart Charts</a>
								</li>
								<li>
									<a href="charts-morris.html" class="slide-item">Morris Charts</a>
								</li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-folder"></i><span class="side-menu__label">Pages</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="user-profile.html" class="slide-item">User Profile</a>
								</li>
								<li>
									<a href="email-inbox.html" class="slide-item">Email Inbox</a>
								</li>
								<li>
									<a href="email-compose.html" class="slide-item">Email</a>
								</li>
								<li>
									<a href="gallery.html" class="slide-item">Gallery</a>
								</li>
								<li>
									<a href="invoice.html" class="slide-item">Invoice</a>
								</li>
								<li>
									<a href="pricing.html" class="slide-item">Pricing Tables</a>
								</li>
								<li>
									<a href="empty.html" class="slide-item">Empty</a>
								</li>
								<li>
									<a href="under-construction.html" class="slide-item">Under Construction</a>
								</li>
								<li>
									<a href="400.html" class="slide-item">Page 400</a>
								</li>
								<li>
									<a href="404.html" class="slide-item">Page 404</a>
								</li>
								<li>
									<a href="500.html" class="slide-item">Page 500</a>
								</li>
								<li>
									<a href="505.html" class="slide-item">Page 505</a>
								</li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-italic"></i><span class="side-menu__label">Icons</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="icons-feather.html" class="slide-item">Feather Icons</a>
								</li>
								<li>
									<a href="icons-fontawesome.html" class="slide-item">Font Awesome Icons</a>
								</li>
								<li>
									<a href="icons-ion.html" class="slide-item">Ion Icons</a>
								</li>
								<li>
									<a href="icons-materialdesign.html" class="slide-item">Materialdesign Icons</a>
								</li>
								<li>
									<a href="icons-nucleo.html" class="slide-item">Nucleo Icons</a>
								</li>
								<li>
									<a href="icons-pe7.html" class="slide-item">pe7 Icons</a>
								</li>
								<li>
									<a href="icons-simpleline.html" class="slide-item">Simpleline Icons</a>
								</li>
								<li>
									<a href="icons-themify.html" class="slide-item">Themify Icons</a>
								</li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-underline"></i><span class="side-menu__label">Ui Elements</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="accordion.html" class="slide-item">Accordion</a>
								</li>
								<li>
									<a href="alerts.html" class="slide-item">Alerts</a>
								</li>
								<li>
									<a href="badges.html" class="slide-item">Badges</a>
								</li>
								<li>
									<a href="buttons.html" class="slide-item">Buttons</a>
								</li>
								<li>
									<a href="carousel.html" class="slide-item">Carousels</a>
								</li>
								<li>
									<a href="colors.html" class="slide-item">Colors</a>
								</li>
								<li>
									<a href="dropdowns.html" class="slide-item">Drop downs</a>
								</li>
								<li>
									<a href="grids.html" class="slide-item">Grids</a>
								</li>
								<li>
									<a href="modal.html" class="slide-item">Modal</a>
								</li>
								<li>
									<a href="navigation.html" class="slide-item">Navigation</a>
								</li>
								<li>
									<a href="pagination.html" class="slide-item">Pagination</a>
								</li>
								<li>
									<a href="popovers.html" class="slide-item">Popovers</a>
								</li>
								<li>
									<a href="progress.html" class="slide-item">Progress</a>
								</li>
								<li>
									<a href="tabs.html" class="slide-item">Tabs</a>
								</li>
								<li>
									<a href="tooltip.html" class="slide-item">Tooltip</a>
								</li>
								<li>
									<a href="typography.html" class="slide-item">Typography</a>
								</li>
							</ul>
						</li>

						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-user"></i><span class="side-menu__label">Account</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="login.html" class="slide-item">Login</a>
								</li>
								<li>
									<a href="register.html" class="slide-item">Register</a>
								</li>
								<li>
									<a href="forgot.html" class="slide-item">Forgot password</a>
								</li>
								<li>
									<a href="lockscreen.html" class="slide-item">Lock screen</a>
								</li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-shopping-cart"></i><span class="side-menu__label">E-commerce</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li>
									<a href="shop.html" class="slide-item">Products</a>
								</li>
								<li>
									<a href="cart.html" class="slide-item">Shopping Cart</a>
								</li>
							</ul>
						</li>

						<li>
							<a class="side-menu__item" href="https://themeforest.net/user/sprukosoft/portfolio"><i class="side-menu__icon fa fa-question-circle"></i><span class="side-menu__label">Help & Support</span></a>
						</li>
					</ul>
				</div>
			</aside>
			<!-- Sidebar menu-->

			<!-- app-content-->
			<div class="app-content ">
				<div class="side-app">
					<div class="main-content">
						<div class="p-2 d-block d-sm-none navbar-sm-search">
							<!-- Form -->
							<form class="navbar-search navbar-search-dark form-inline ml-lg-auto">
								<div class="form-group mb-0">
									<div class="input-group input-group-alternative">
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="fas fa-search"></i></span>
										</div><input class="form-control" placeholder="Search" type="text">
									</div>
								</div>
							</form>
						</div>
						<!-- Top navbar -->
						<nav class="navbar navbar-top  navbar-expand-md navbar-dark" id="navbar-main">
							<div class="container-fluid">
								<a aria-label="Hide Sidebar" class="app-sidebar__toggle" data-toggle="sidebar" href="#"></a>

								<!-- Horizontal Navbar -->

								<!-- Brand -->
								<a class="navbar-brand pt-0 d-md-none" href="index.html">
									<img src="assets/img/brand/logo-light.png" class="navbar-brand-img" alt="...">
								</a>
								<!-- Form -->
								<form class="navbar-search navbar-search-dark form-inline mr-3 ml-lg-auto">
									<div class="form-group mb-0">
										<div class="input-group input-group-alternative">
											<div class="input-group-prepend">
												<span class="input-group-text"><i class="fas fa-search"></i></span>
											</div><input class="form-control" placeholder="Search" type="text">
										</div>
									</div>
								</form>
								<!-- User -->
								<ul class="navbar-nav align-items-center ">
									<li class="nav-item dropdown">
										<a aria-expanded="false" aria-haspopup="true" class="nav-link pr-md-0" data-toggle="dropdown" href="#" role="button">
										<div class="media align-items-center">
											<span class="avatar avatar-sm rounded-circle"><img alt="Image placeholder" src="assets/img/faces/female/32.jpg"></span>
											<div class="media-body ml-2 d-none d-lg-block">
												<span class="mb-0 ">Cori Stover</span>
											</div>
										</div></a>
										<div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
											<div class=" dropdown-header noti-title">
												<h6 class="text-overflow m-0">Welcome!</h6>
											</div>
											<a class="dropdown-item" href="user-profile.html"><i class="ni ni-single-02"></i> <span>My profile</span></a>
											<a class="dropdown-item" href="#"><i class="ni ni-settings-gear-65"></i> <span>Settings</span></a>
											<a class="dropdown-item" href="#"><i class="ni ni-calendar-grid-58"></i> <span>Activity</span></a>
											<a class="dropdown-item" href="#"><i class="ni ni-support-16"></i> <span>Support</span></a>
											<div class="dropdown-divider"></div><a class="dropdown-item" href="login.html"><i class="ni ni-user-run"></i> <span>Logout</span></a>
										</div>
									</li>
								</ul>
							</div>
						</nav>
						<!-- Top navbar-->

						<!-- Page content -->
						<div class="container-fluid pt-8">
							<div class="page-header mt-0 shadow p-3">
								<ol class="breadcrumb mb-sm-0">
									<li class="breadcrumb-item"><a href="#">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Sales Dashboard</li>
								</ol>
								<div class="btn-group mb-0">
									<button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Actions</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="#"><i class="fas fa-plus mr-2"></i>Add new Page</a>
										<a class="dropdown-item" href="#"><i class="fas fa-eye mr-2"></i>View the page Details</a>
										<a class="dropdown-item" href="#"><i class="fas fa-edit mr-2"></i>Edit Page</a>
										<div class="dropdown-divider"></div>
										<a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i> Settings</a>
									</div>
								</div>
							</div>
							<div class="card shadow overflow-hidden">
								<div class="">
									<div class="row">
										<div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 stats">
											<div class="text-center">
												<p class="text-light">
													<i class="fas fa-chart-line mr-2"></i>
													Today sales
												</p>
												<h2 class="text-primary text-xxl">1235</h2>
												<a href="#" class="btn btn-outline-primary btn-pill btn-sm">30% decrease</a>
											</div>
										</div>
										<div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 stats">
											<div class="text-center">
												<p class="text-light">
												  <i class="fas fa-users mr-2"></i>
												  New Users
												</p>
												<h2 class="text-yellow text-xxl">523</h2>
												<a href="#" class="btn btn-outline-yellow btn-pill btn-sm">10% increase</a>
											</div>
										</div>
										<div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 stats">
											<div class="text-center">
												<p class="text-light">
												  <i class="fas fa-cart-arrow-down mr-2"></i>
												  Today Orders
												</p>
												<h2 class="text-warning text-xxl">785</h2>
												<a href="#" class="btn btn-outline-warning btn-pill btn-sm">9% decrease</a>
											</div>
										</div>
										<div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 stats">
											<div class="text-center">
												<p class="text-light">
												  <i class="fas fa-signal mr-2"></i>
												  Today sales Revenue
												</p>
												<h2 class="text-danger text-xxl">$ 125</h2>
												<a href="#" class="btn btn-outline-danger btn-pill btn-sm">10% decrease</a>
											</div>
										</div>
										<div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 stats">
											<div class="text-center">
												<p class="text-light">
												  <i class="fas fa-dollar-sign mr-2"></i>
												 Today Profit
												</p>
												<h2 class="text-success text-xxl">$ 30</h2>
												<a href="#" class="btn btn-outline-success btn-pill btn-sm">5% increase</a>
											</div>
										</div>
										<div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 stats">
											<div class="text-center">
												<p class="text-light">
												  <i class="fas fa-briefcase mr-2"></i>
												  Market Value
												</p>
												<h2 class="text-primary text-xxl">12</h2>
												<a href="#" class="btn btn-outline-primary btn-pill btn-sm">View</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xl-3">
									<div class="card shadow overflow-hidden">
										<div class="card-body">
											<div class="widget text-center">
												<div><i class="fas fa-users fa-5x text-yellow"></i></div>
												<h4 class="text-muted mt-2 mb-0">Online Visitors</h4>
												<h2 class="display-2 mb-0">25,685</h2>
												<a href="#" class="btn btn-outline-yellow mt-3 btn-sm btn-pill">view all</a>
											</div>
										</div>
										<span class="updating-chart" data-peity='{ "fill": ["#ffa21d"]}'>5,3,9,6,5,9,2,5,3,6,7,8,6</span>
									</div>
								</div>
								<div class="col-xl-3">
									<div class="">
										<div class="">
											<div class="row">
												<div class="col-xl-12 col-lg-12 col-sm-12">
													<div class="card shadow overflow-hidden">
														<div class="card-body pb-0">
															<div class="widget text-center">
																<small class="text-muted">Sales Monthly</small>
																<h2 class="text-xxl mb-0">$ 8,343</h2>
															</div>
														</div>
														<span class="bar" data-peity='{ "fill": ["#00c3ed"]}'>5,4,5,2,8,4,5,6,5,2,4,4,8,4,6,2,3,4</span>
													</div>
													<div class="card shadow overflow-hidden">
														<div class="card-body pb-0">
															<div class="widget text-center">
																<small class="text-muted">Sales Weekly</small>
																<h2 class="text-xxl mb-0">$ 683</h2>
															</div>
														</div>
														<span class="bar" data-peity='{ "fill": ["#18b16f"]}'>5,4,5,2,8,4,5,6,5,2,4,4,8,4,6,2,3,4</span>

													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-xl-6">
									<div class="">
										<div class="">
											<div class="row">
												<div class="col-xl-6 col-lg-6 col-sm-6">
													<div class="card shadow">
														<div class="card-body">
															<div class="widget text-center">
																<small class="">Average Revenue per unit</small>
																<h2 class="text-xxl mb-1 text-success">$ 142</h2>
																<p class="mb-0"><span class=""><i class="fas fa-caret-up ml-1 text-success"></i> 4%</span>  last month</p>
															</div>
														</div>
													</div>
													<div class="card shadow">
														<div class="card-body">
															<div class="widget text-center">
																<small class="">Customer Lifetime Value</small>
																<h2 class="text-xxl mb-1 text-yellow">$ 256</h2>
																<p class="mb-0"><span class=""><i class="fas fa-caret-down text-danger ml-1"></i> 5%</span> last month</p>
															</div>
														</div>
													</div>
												</div>
												<div class="col-xl-6 col-lg-6 col-sm-6">
													<div class="card shadow">
														<div class="card-body">
															<div class="widget text-center">
																<small class="">Customer Acquisition Cost</small>
																<h2 class="text-xxl text-primary mb-1">$ 329</h2>
																<p class="mb-0"><span class=""><i class="fas fa-caret-up text-success ml-1"></i> 6%</span> last month</p>
															</div>
														</div>
													</div>
													<div class="card shadow">
														<div class="card-body">
															<div class="widget text-center">
																<small class="">Monthly Sales Growth</small>
																<h2 class="text-xxl text-danger mb-1">12%</h2>
																<p class="mb-0"><span class=""><i class="fas fa-caret-down text-danger ml-1"></i> 8%</span> last month</p>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-xl-7">
									<div class="card  shadow overflow-hidden">
										<div class="card-header bg-transparent ">
											<div class="row align-items-center">
												<div class="col">
													<h6 class="text-uppercase text-light ls-1 mb-1">Overview</h6>
													<h2 class="mb-0">Details Of Revenue and profit</h2>
												</div>

											</div>
										</div>
										<div class="card-body">
											<!-- Chart -->
											<div id="echart" class="chart-dropshadow h-400"></div>
										</div>
									</div>
								</div>
								<div class="col-xl-5">
									<div class="card  shadow overflow-hidden">
										<div class="card-header bg-transparent">
											<div class="row align-items-center">
												<div class="col">
													<h6 class="text-uppercase text-light ls-1 mb-1">Overview</h6>
													<h2 class="mb-0">Monthly Sales Performance</h2>
												</div>

											</div>
										</div>
										<div class="card-body">
											<!-- Chart -->
											<div id="echart2" class="chart-dropshadow h-400"></div>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-12">
									<div class="card shadow">
										<div class="card-header bg-transparent">
											<div class="row align-items-center">
												<div class="col">
													<h6 class="text-uppercase text-light ls-1 mb-1">Revenue</h6>
													<h2 class="mb-0">Revenue Generated By Country</h2>
												</div>
											</div>
										</div>
										<div class="">
											<div class="row">
												<div class="col-xl-4">
													<div class="card-body">
														<div class="progress-wrapper pt-2">
															<div class="progress-info">
																<div class="progress-label">
																	<span>India</span>
																</div>
																<div class="progress-percentage">
																	<span>70%</span>
																</div>
															</div>
															<div class="progress">
																<div class="progress-bar bg-primary" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%;"></div>
															</div>
														</div>
														<div class="progress-wrapper pt-2">
															<div class="progress-info">
																<div class="progress-label">
																	<span>Singapore</span>
																</div>
																<div class="progress-percentage">
																	<span>45%</span>
																</div>
															</div>
															<div class="progress">
																<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 45%;"></div>
															</div>
														</div>
														<div class="progress-wrapper pt-2">
															<div class="progress-info">
																<div class="progress-label">
																	<span>Bahrain</span>
																</div>
																<div class="progress-percentage">
																	<span>60%</span>
																</div>
															</div>
															<div class="progress">
																<div class="progress-bar bg-info" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
															</div>
														</div>
														<div class="progress-wrapper pt-2">
															<div class="progress-info">
																<div class="progress-label">
																	<span>Maldives</span>
																</div>
																<div class="progress-percentage">
																	<span>56%</span>
																</div>
															</div>
															<div class="progress">
																<div class="progress-bar bg-success" role="progressbar" aria-valuenow="56" aria-valuemin="0" aria-valuemax="100" style="width: 56%;"></div>
															</div>
														</div>
														<div class="progress-wrapper pt-2">
															<div class="progress-info">
																<div class="progress-label">
																	<span>Canada</span>
																</div>
																<div class="progress-percentage">
																	<span>30%</span>
																</div>
															</div>
															<div class="progress">
																<div class="progress-bar bg-danger" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 30%;"></div>
															</div>
														</div>
														<div class="progress-wrapper pt-2">
															<div class="progress-info">
																<div class="progress-label">
																	<span>Palau</span>
																</div>
																<div class="progress-percentage">
																	<span>42%</span>
																</div>
															</div>
															<div class="progress mb-0">
																<div class="progress-bar bg-default" role="progressbar" aria-valuenow="42" aria-valuemin="0" aria-valuemax="100" style="width: 42%;"></div>
															</div>
														</div>
													</div>
												</div>
												<div class="col-xl-8 worldmap">
													<div class="card-body">
														<div id="world-map-markers" class="worldh h-400" ></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col">
									<div class="card shadow">
										<div class="card-header bg-transparent border-0">
											<h2 class=" mb-0">Product Sales Tables</h2>
										</div>
										<div class="">
											<div class="grid-margin">
												<div class="">
													<div class="table-responsive">
														<table class="table card-table table-vcenter text-nowrap align-items-center">
															<thead class="thead-light">
																<tr>
																	<th>Product</th>
																	<th>Sold</th>
																	<th>Record point</th>
																	<th>Stock</th>
																	<th>Amount</th>
																	<th>Stock Status</th>
																</tr>
															</thead>
															<tbody>
																<tr>
																	<td class="text-sm font-weight-600">Women Wallet-E32N</td>
																	<td>18</td>
																	<td>05</td>
																	<td>112</td>
																	<td>$ 2,356</td>
																	<td>In Stock</td>
																</tr>
																<tr>
																	<td class="text-sm font-weight-600">Phone-345S</td>
																	<td >10</td>
																	<td>04</td>
																	<td>210</td>
																	<td>$ 3,522</td>
																	<td>In Stock</td>
																</tr>
																<tr>
																	<td class="text-sm font-weight-600">Doll-Elephant</td>
																	<td >15</td>
																	<td>05</td>
																	<td>215</td>
																	<td>$ 5,362</td>
																	<td>In Stock</td>
																</tr>
																<tr>
																	<td class="text-sm font-weight-600">Women-Kurtis</td>
																	<td>21</td>
																	<td>07</td>
																	<td>102</td>
																	<td>$ 1,326</td>
																	<td>In Stock</td>
																</tr>
																<tr>
																	<td class="text-sm font-weight-600">Mens Shoes</td>
																	<td>34</td>
																	<td>10</td>
																	<td>325</td>
																	<td>$ 5,234</td>
																	<td>In Stock</td>
																</tr>
																<tr>
																	<td class="text-sm font-weight-600">Mens Gold Metal Watch</td>
																	<td>11</td>
																	<td>04</td>
																	<td>5</td>
																	<td>$ 3,256</td>
																	<td>
																		<i class="fas fa-exclamation-triangle text-warning"></i>  Out of stock
																	</td>
																</tr>
																<tr>
																	<td class="text-sm font-weight-600">Laptop</td>
																	<td>60</td>
																	<td>10</td>
																	<td>0</td>
																	<td>$ 7,652</td>
																	<td>
																		<i class="fas fa-exclamation-triangle text-danger"></i> Out of stock
																	</td>
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						<!-- Footer -->
						<footer class="footer">
							<div class="row align-items-center justify-content-xl-between">
								<div class="col-xl-6">
									<div class="copyright text-center text-xl-left text-muted">
										<p class="text-sm font-weight-500">Copyright 2019 © All Rights Reserved.Atlas Software Park</p>
									</div>
								</div>
								<div class="col-xl-6">
									<p class="float-right text-sm font-weight-500"><a href="www.atlassoftwarepark.com">Atlas Software Park</a></p>
								</div>
							</div>
						</footer>
							<!-- Footer -->
						</div>
					</div>
				</div>
			</div>
			<!-- app-content-->
		</div>
	</div>
	<!-- Back to top -->
	<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

	<!-- Ansta Scripts -->
	<!-- Core -->
	<script src="assets/plugins/jquery/dist/jquery.min.js"></script>
	<script src="assets/js/popper.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

	<!-- Echarts JS -->
	<script src="assets/plugins/chart-echarts/echarts.js"></script>

	<!-- Fullside-menu Js-->
	<script src="assets/plugins/toggle-sidebar/js/sidemenu.js"></script>

	<!-- Custom scroll bar Js-->
	<script src="assets/plugins/customscroll/jquery.mCustomScrollbar.concat.min.js"></script>

	<!-- peitychart -->
	<script src="assets/plugins/peitychart/jquery.peity.min.js"></script>
	<script src="assets/plugins/peitychart/peitychart.init.js"></script>

	<!-- Vector Plugin -->
	<script src="assets/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
	<script src="assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
	<script src="assets/plugins/jvectormap/gdp-data.js"></script>
	<script src="assets/plugins/jvectormap/jquery-jvectormap-us-aea-en.js"></script>
	<script src="assets/plugins/jvectormap/jquery-jvectormap-uk-mill-en.js"></script>
	<script src="assets/plugins/jvectormap/jquery-jvectormap-au-mill.js"></script>
	<script src="assets/plugins/jvectormap/jquery-jvectormap-ca-lcc.js"></script>
	<script src="assets/js/dashboard2map.js"></script>

	<!-- Ansta JS -->
	<script src="assets/js/custom.js"></script>
	<script src="assets/js/dashboard-sales.js"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\e-RUS\resources\views/index.blade.php ENDPATH**/ ?>