<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Atlas | Software Park</title>

    <link rel="shortcut icon" href="<?php echo e(asset('asset/img/favicon.ico')); ?>">

    <!--STYLESHEET-->
    <!--=================================================-->

    <!--Roboto Slab Font [ OPTIONAL ] -->
    <link href="http://fonts.googleapis.com/css?family=Roboto+Slab:400,300,100,700" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Roboto:500,400italic,100,700italic,300,700,500italic,400" rel="stylesheet">

    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(asset('asset/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!--Jasmine Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(asset('asset/css/style.css')); ?>" rel="stylesheet">
    <!--Font Awesome [ OPTIONAL ]-->
    <link href="<?php echo e(asset('asset/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!--Switchery [ OPTIONAL ]-->
    <link href="<?php echo e(asset('asset/plugins/switchery/switchery.min.css')); ?>" rel="stylesheet">
    <!--Bootstrap Select [ OPTIONAL ]-->
    <link href="<?php echo e(asset('asset/plugins/bootstrap-select/bootstrap-select.min.css')); ?>" rel="stylesheet">
    <!--Demo [ DEMONSTRATION ]-->
    <link href="<?php echo e(asset('asset/css/demo/jasmine.css')); ?>" rel="stylesheet">
    <!--SCRIPT-->
    <!--=================================================-->
    <!--Page Load Progress Bar [ OPTIONAL ]-->
    <link href="<?php echo e(asset('asset/plugins/pace/pace.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('asset/plugins/pace/pace.min.js')); ?>"></script>

</head>
    <!--TIPS-->
    <!--You may remove all ID or Class names which contain "demo-", they are only used for demonstration. -->
    <body>
        <div id="container" class="effect mainnav-lg navbar-fixed mainnav-fixed">
            <!--NAVBAR-->
            <!--===================================================-->
            <header id="navbar">
                <div id="navbar-container" class="boxed">
                    <!--Brand logo & name-->
                    <!--================================-->
                    <div class="navbar-header">
                        <a href="index.html" class="navbar-brand">
                            <i class="fa fa-cube brand-icon"></i>
                            <div class="brand-title">
                                <span class="brand-text">e-RUS</span>
                            </div>
                        </a>
                    </div>
                    <div class="navbar-content clearfix">
                        <ul class="nav navbar-top-links pull-left">
                            <li class="tgl-menu-btn">
                                <a class="mainnav-toggle" href="#"> <i class="fa fa-navicon fa-lg"></i> </a>
                            </li>
                        </ul>

                    </div>
                </div>
            </header>
            <!--===================================================-->
            <!--END NAVBAR-->
            <div class="boxed">
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container">
              <div id="profilebody">
                <div class="pad-all animated fadeInDown">
                  <div class="row">
                    <div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
                      <div class="panel panel-default mar-no">
                        <div class="panel-body">
                          <a href="JavaScript:void(0);">
                            <div class="pull-left"> <p class="profile-title text-bricky">Users</p> </div>
                            <div class="pull-right text-bricky"> <i class="fa fa-users fa-4x"></i> </div>
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
                      <div class="panel panel-default mar-no">
                        <div class="panel-body">
                          <a href="JavaScript:void(0);">
                            <div class="pull-left"> <p class="profile-title text-bricky">Inbox</p> </div>
                            <div class="pull-right text-bricky"> <i class="fa fa-envelope fa-4x"></i> </div>
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
                      <div class="panel panel-default mar-no">
                        <div class="panel-body">
                          <a href="JavaScript:void(0);">
                            <div class="pull-left"> <p class="profile-title text-bricky">FAQ</p> </div>
                            <div class="pull-right text-bricky"> <i class="fa fa-headphones fa-4x"></i> </div>
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
                      <div class="panel panel-default mar-no">
                        <div class="panel-body">
                          <a href="JavaScript:void(0);">
                            <div class="pull-left"> <p class="profile-title text-bricky">Settings</p> </div>
                            <div class="pull-right text-bricky"> <i class="fa fa-cogs fa-4x"></i> </div>
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
                      <div class="panel panel-default mar-no">
                        <div class="panel-body">
                          <a href="JavaScript:void(0);">
                            <div class="pull-left"> <p class="profile-title text-bricky">Calender</p> </div>
                            <div class="pull-right text-bricky"> <i class="fa fa-calendar fa-4x"></i> </div>
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
                      <div class="panel panel-default mar-no">
                        <div class="panel-body">
                          <a href="JavaScript:void(0);">
                            <div class="pull-left"> <p class="profile-title text-bricky">Pictures</p> </div>
                            <div class="pull-right text-bricky"> <i class="fa fa-picture-o fa-4x"></i> </div>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
                    <!--Page Title-->
                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                    <div class="pageheader">
                        <h3><i class="fa fa-home"></i> Dashboard </h3>
                        <div class="breadcrumb-wrapper">
                            <span class="label">You are here:</span>
                            <ol class="breadcrumb">
                                <li> <a href="#"> Home </a> </li>
                                <li class="active"> Dashboard </li>
                            </ol>
                        </div>
                    </div>
                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                    <!--End page title-->
                    <!--Page content-->
                    <!--===================================================-->
                    <div class="container">
                      <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
                </div>
                <!--===================================================-->
                <!--END CONTENT CONTAINER-->
                <!--MAIN NAVIGATION-->
                <!--===================================================-->
                <nav id="mainnav-container">
                    <div id="mainnav">
                        <!--Menu-->
                        <!--================================-->
                        <div id="mainnav-menu-wrap">
                            <div class="nano">
                                <div class="nano-content">
                                    <ul id="mainnav-menu" class="list-group">
                                        <!--Category name-->
                                        <li class="list-header">Navigation</li>
                                        <!--Menu list item-->
                                        <li>
                                            <a href="javascript:void(0)">
                                            <i class="fa fa-home"></i>
                                            <span class="menu-title">Dashboard</span>
                                            <i class="arrow"></i>
                                            </a>
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="http://localhost:8000/dashboard"><i class="fa fa-caret-right"></i> Dashboard</a></li>
                                            </ul>
                                        </li>
                                        <!--Menu list item-->
                                        <li class="list-divider"></li>
                                        <!--Category name-->
                                        <li class="list-header">Components</li>
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                            <i class="fa fa-th"></i>
                                            <span class="menu-title">
                                            <strong>Union Area</strong>
                                            </span>
                                            <i class="arrow"></i>
                                            </a>
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="#"><i class="fa fa-caret-right"></i> Add Area Info </a></li>
                                                <li><a href="#"><i class="fa fa-caret-right"></i> All Information </a></li>
                                            </ul>
                                        </li>
                                        <!--Menu list item-->
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                            <i class="fa fa-user"></i>
                                            <span class="menu-title">census</span>
                                            <i class="arrow"></i>
                                            </a>
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="#"><i class="fa fa-caret-right"></i> Add People Info </a></li>
                                                <li><a href="#"><i class="fa fa-caret-right"></i> All People </a></li>
                                            </ul>
                                        </li>
                                        <!--Menu list item-->

                                        <li>
                                            <a href="#">
                                            <i class="fa fa-university"></i>
                                            <span class="menu-title">Tax Management</span>
                                            <i class="arrow"></i>
                                            </a>
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="add_education_packages.html"><i class="fa fa-caret-right"></i> Add Packages </a></li>
                                                <li><a href="all_education_packages.html"><i class="fa fa-caret-right"></i> Packages List </a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <i class="fa fa-hospital-o"></i>
                                            <span class="menu-title">Rason Management</span>
                                            <i class="arrow"></i>
                                            </a>
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="add_medical_packages.html"><i class="fa fa-caret-right"></i> Add Packages </a></li>
                                                <li><a href="all_medical_packages.html"><i class="fa fa-caret-right"></i> Packages List </a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <i class="glyphicon glyphicon-tags"></i>
                                            <span class="menu-title">Booking Ticket</span>
                                            <i class="arrow"></i>
                                            </a>
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="all_booking_list.html"><i class="fa fa-caret-right"></i> Booking List </a></li>
                                                <li><a href="hajj_booking_list.html"><i class="fa fa-caret-right"></i> Hajj Booking </a></li>
                                                <li><a href="work_booking_list.html"><i class="fa fa-caret-right"></i> Work Booking </a></li>
                                                <li><a href="travel_booking_list.html"><i class="fa fa-caret-right"></i> Travel Booking </a></li>
                                                <li><a href="education_booking_list.html"><i class="fa fa-caret-right"></i> Education Booking </a></li>
                                                <li><a href="medical_booking_list.html"><i class="fa fa-caret-right"></i> Medical Booking </a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <i class="fa fa-book"></i>
                                            <span class="menu-title">
                                            Massages
                                            </span>
                                            </a>
                                        </li>

                                        <li class="list-divider"></li>
                                        <!--Category name-->
                                        <li class="list-header">Extra</li>
                                        <li>
                                            <a href="calendar.html">
                                            <i class="glyphicon glyphicon-cog"></i>
                                            <span class="menu-title">
                                            Settings
                                            </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="calendar.html">
                                            <i class="glyphicon glyphicon-off"></i>
                                            <span class="menu-title">
                                            Log Out
                                            </span>
                                            </a>
                                        </li>
                                        <!--Menu list item-->
                                        <li>
                                            <a href="ui-widgets.html">
                                            <i class="glyphicon glyphicon-info-sign"></i>
                                            <span class="menu-title">
                                            <strong>About Us</strong>
                                            </span>
                                            </a>
                                        </li>
                                    </ul>
                                    <!--Widget-->
                                    <!--================================-->
                                    <div class="mainnav-widget">
                                        <!-- Show the button on collapsed navigation -->
                                        <div class="show-small">
                                            <a href="#" data-toggle="menu-widget" data-target="#demo-wg-server">
                                            <i class="fa fa-desktop"></i>
                                            </a>
                                        </div>
                                        <!-- Hide the content on collapsed navigation -->
                                        <div id="demo-wg-server" class="hide-small mainnav-widget-content">
                                            <ul class="list-group">
                                                <li class="list-header pad-no pad-ver">Server Status</li>
                                                <li class="mar-btm">
                                                    <span class="label label-primary pull-right">15%</span>
                                                    <p>CPU Usage</p>
                                                    <div class="progress progress-sm">
                                                        <div class="progress-bar progress-bar-primary" style="width: 15%;">
                                                            <span class="sr-only">15%</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mar-btm">
                                                    <span class="label label-purple pull-right">75%</span>
                                                    <p>Bandwidth</p>
                                                    <div class="progress progress-sm">
                                                        <div class="progress-bar progress-bar-purple" style="width: 75%;">
                                                            <span class="sr-only">75%</span>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!--================================-->
                                    <!--End widget-->
                                </div>
                            </div>
                        </div>
                        <!--================================-->
                        <!--End menu-->
                    </div>
                </nav>

            </div>
            <!-- FOOTER -->
            <!--===================================================-->
            <footer id="footer">
                <div class="hide-fixed pull-right pad-rgt">Currently v2.2</div>
                <p class="pad-lft">Copyrights © 2019-2020 <a href="https://www.atlassoftwarepark.com/" target="_blank">Atlas Software Park</a></p>
            </footer>
        </div>
        <!--=================================================-->

        <!--jQuery [ REQUIRED ]-->
        <script src="<?php echo e(asset('asset/js/jquery-2.1.1.min.js')); ?>"></script>

        <!--BootstrapJS [ RECOMMENDED ]-->
        <script src="<?php echo e(asset('asset/js/bootstrap.min.js')); ?>"></script>

        <!--Fast Click [ OPTIONAL ]-->
        <script src="<?php echo e(asset('asset/plugins/fast-click/fastclick.min.js')); ?>"></script>

        <!--Jasmine Admin [ RECOMMENDED ]-->
        <script src="<?php echo e(asset('asset/js/scripts.js')); ?>"></script>

        <!--Switchery [ OPTIONAL ]-->
        <script src="<?php echo e(asset('asset/plugins/switchery/switchery.min.js')); ?>"></script>

        <!--Bootstrap Select [ OPTIONAL ]-->
        <script src="<?php echo e(asset('asset/plugins/bootstrap-select/bootstrap-select.min.js')); ?>"></script>

        <!--Fullscreen jQuery [ OPTIONAL ]-->
        <script src="<?php echo e(asset('asset/plugins/screenfull/screenfull.js')); ?>"></script>

        <!--Demo script [ DEMONSTRATION ]-->
        <script src="<?php echo e(asset('asset/js/demo/jasmine.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\e-RUS\resources\views/layout/master.blade.php ENDPATH**/ ?>